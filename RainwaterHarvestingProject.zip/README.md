# 🌧️ Smart Rainwater Harvesting Monitoring System

A real-time IoT-based water harvesting monitoring system with push notifications and user dashboards.

---

## 🚀 Features

- 📡 Real-time water level & rain status monitoring
- 📲 React Native app with login & user dashboard
- 🔔 Push notifications when tank is near overflow
- 🌐 Flask REST API backend with SQLite
- 🔐 User-specific data and alerts

---

## 🧱 Architecture

```
Sensors (Rain + Ultrasonic) → NodeMCU → Flask API → SQLite → React Native App (Expo)
```

---

## 🛠️ Tech Stack

- NodeMCU (ESP8266)
- Rain Sensor + Ultrasonic Sensor
- Flask + SQLite
- React Native (Expo)
- Victory Native for charts
- Expo Push Notifications

---

## 📦 Installation

### 📍 Backend (Flask)

```bash
cd backend
pip install -r requirements.txt
python app.py
```

### 📱 Frontend (React Native)

```bash
cd mobile-app
npm install
npx expo start
```

Use Expo Go app on your phone to scan the QR code.

---

## 📡 NodeMCU Code

ESP8266 sends:
```json
POST /api/upload_data
{
  "user_id": 1,
  "rain": 1,
  "water_level_cm": 38.5
}
```

Modify Wi-Fi and endpoint URL in `main.ino`.

---

## 🧪 Test User Credentials

| Username | Password |
|----------|----------|
| testuser | test123  |

---

## 📈 Data Visualization

- Water level vs Time graph
- Rain status toggle
- Push notifications via Expo

---

## ✅ Future Improvements

- Add analytics: Monthly savings estimate
- Deploy backend on Render or Railway
- Admin dashboard for all users

---

## 👨‍💻 Developed By

**Dhruv Tripathi** – CSE (AI/ML)  
Rainwater Project 2025 | IoT + Full Stack + Realtime
